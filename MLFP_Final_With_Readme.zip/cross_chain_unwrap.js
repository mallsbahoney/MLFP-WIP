export function unwrapCrossChain(token, destinationChain, address) {
    return `Simulating unwrap of ${token} and sending to ${address} on ${destinationChain}`;
}