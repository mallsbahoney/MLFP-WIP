export async function autoSell(token) {
    const logs = [];
    logs.push(`Swapping ${token} to SOL via Raydium...`);
    logs.push('Selling SOL to fiat using MoonPay (placeholder)...');
    return logs;
}