export function devWrapTrigger(token, dapp, destinationWallet) {
    return `DApp ${dapp} triggered wrapping of ${token}. Final destination: ${destinationWallet}`;
}