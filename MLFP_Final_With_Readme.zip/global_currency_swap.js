export function simulateCurrencySwap(fromCurrency, toCurrency, amount) {
    return `${amount} ${fromCurrency} → ${toCurrency} via SOL and MoonPay simulation`;
}