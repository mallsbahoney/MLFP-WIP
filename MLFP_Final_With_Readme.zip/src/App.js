import React from 'react';
import WalletPage from './pages/WalletPage';

function App() {
  return <WalletPage />;
}

export default App;