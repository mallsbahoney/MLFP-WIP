// moonpaySimulator.js — Placeholder module for src/utils
