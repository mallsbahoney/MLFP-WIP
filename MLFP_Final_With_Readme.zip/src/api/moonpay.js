// Placeholder: MoonPay SDK/API integration will go here
export const moonpayBuyCrypto = async () => {
  // Simulate MoonPay fiat → crypto
};

export const moonpaySellCrypto = async () => {
  // Simulate MoonPay crypto → fiat
};