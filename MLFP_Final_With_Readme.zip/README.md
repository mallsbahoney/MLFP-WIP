
# MLFP (MallsLabs Fiat Protocol)

MLFP is a Solana-powered protocol integrating MoonPay and Raydium to enable seamless, real-time fiat-to-crypto and crypto-to-fiat payments — usable globally by everyday users and merchants. It unlocks cross-chain interaction, automatic conversions, and real-world commerce through just a wallet app.

...

> Two wallets. One protocol. Infinite use cases.
