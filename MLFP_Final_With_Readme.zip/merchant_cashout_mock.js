export function simulateMerchantCashout(amount) {
    return `Merchant cashing out ${amount} SOL to fiat (MoonPay mock)...`;
}