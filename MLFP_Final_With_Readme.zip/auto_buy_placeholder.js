export function autoBuyPrompt() {
    return {
        status: 'pending',
        message: 'Fiat purchase flow would be initiated here using MoonPay API.',
    };
}